
var gateway = require('./SmsGateway.js');
var threshold = 3;
var counter = {};
function send_message(user, message, failure_callback) {
    if (counter.user > 0) {
        if (counter.user >= threshold) {
            console.log(process.uptime() + " \"" + message + "\" failed due to limitation (" + user + ")");
            failure_callback(user, message);
            setTimeout(function() {
                counter.user --;
            }, 1000/threshold);
            return;
        } else {
            counter.user++;
        }
    } else {
        counter.user = 1;
    }
    var result = gateway.post_sms(message);
    if (result) {
        console.log(process.uptime() + " \"" + message + "\" sent successfully." );
    } else {
        console.log(process.uptime() + " \"" + message + "\" failed due to gateway" );
        failure_callback(user, message);
    }
    setTimeout(function() {
        counter.user --;
    }, 1000/3);
}

module.exports = {
    send_message: send_message
}