var config = {
    error_rate: 0.5
}
FakeSMSGateway = {
    post_sms : function(message) {
        var rnd = Math.random();
        if (rnd > config.error_rate) {
            return true;
        } else {
            return false;
        }
    }
}
module.exports = FakeSMSGateway;