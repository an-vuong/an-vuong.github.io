var smsClient = require('./SmsClient.js');
function callback(user, message) {
    console.log(process.uptime() + " \"" + message + "\" failed to send. Retry in 1000ms." )
    setTimeout(function() {
        smsClient.send_message(user, message, callback);
    }, 1000);
}

setTimeout(function() { smsClient.send_message('UserA', 'Message 1', callback);}, 1000);
setTimeout(function() { smsClient.send_message('UserA', 'Message 2', callback);}, 2000);
setTimeout(function() { smsClient.send_message('UserB', 'Message 3', callback);}, 500);
setTimeout(function() { smsClient.send_message('UserB', 'Message 4', callback);}, 600);
setTimeout(function() { smsClient.send_message('UserB', 'Message 5', callback);}, 700);
setTimeout(function() { smsClient.send_message('UserB', 'Message 6', callback);}, 800);